<?php 

echo "Primer ejemplo con PHP";

//esto es un comentario corto

/* esto es un comentario largo para varias líneas*/

 ?>